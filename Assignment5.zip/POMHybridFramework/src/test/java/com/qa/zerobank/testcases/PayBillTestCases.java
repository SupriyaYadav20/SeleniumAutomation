package com.qa.zerobank.testcases;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.zerobank.base.TestBase;
import com.qa.zerobank.pages.AccountSummaryPage;
import com.qa.zerobank.pages.HomePage;
import com.qa.zerobank.pages.LogInPage;
import com.qa.zerobank.pages.PayBills;
import com.qa.zerobank.util.TestUtil;

public class PayBillTestCases extends TestBase  {
	HomePage homepage;
	LogInPage logInPage;
	PayBills payBills;
	AccountSummaryPage accountSummaryPage;
	TestUtil testUtil;

	public PayBillTestCases() {
		super();
	}
	
	
	@BeforeMethod
	public void beforeMethod() 
	{
		initialization();
		homepage = new HomePage();
		logInPage = new LogInPage();
		accountSummaryPage = new AccountSummaryPage();
		testUtil=new TestUtil();
		payBills=new PayBills();
	}

	@AfterMethod
	public void cleanUp()
	{
		TestUtil.takeScreenShotAtEndOfTest("PayBills");
		killDriver();
	
	}
	
	@Test(priority=1)
	public void validatePayBillPage()
	{
		logInPage=homepage.clickOnSignInButton();
		logInPage.logIn();
		accountSummaryPage.assertAccountSummaryPageTitle();
		payBills.paySavedPayee();
		payBills.assertPayBillPageTitle();
	}
	
	
	
	@Test(priority=2)
	public void validatePayBillFunctionality_Positive()
	{
		logInPage=homepage.clickOnSignInButton();
		logInPage.logIn();
		payBills.paySavedPayee();
		payBills.make_Payment();
	
	}
	
	@Test(priority=3,groups="Regression")
	public void validatePayBillFunctionality_Negative()
	{
		logInPage=homepage.clickOnSignInButton();
		logInPage.logIn();
		payBills.paySavedPayee();
		payBills.make_Payment_InvalidDate();
	
	}
	@Test(priority=4,groups="Regression")
	public void validateAddNewPayeeFunctionality_Negative()
	{
		logInPage=homepage.clickOnSignInButton();
		logInPage.logIn();
		//payBills.paySavedPayee();
		payBills.Add_New_Payee();
	
	}
}

	

