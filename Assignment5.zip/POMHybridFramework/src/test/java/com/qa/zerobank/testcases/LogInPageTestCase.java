package com.qa.zerobank.testcases;

import org.testng.annotations.Test;

import com.qa.zerobank.base.TestBase;
import com.qa.zerobank.pages.AccountSummaryPage;
import com.qa.zerobank.pages.ForgotPasswordPage;
import com.qa.zerobank.pages.HomePage;
import com.qa.zerobank.pages.LogInPage;
import com.qa.zerobank.util.TestUtil;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;

public class LogInPageTestCase extends TestBase
{
	HomePage homepage;
	LogInPage logInPage;
	AccountSummaryPage accountSummaryPage;
	TestUtil testUtil;
	ForgotPasswordPage forgotPasswordPage;

	public LogInPageTestCase() {
		super();
	}

	@BeforeMethod
	public void beforeMethod() 
	{
		initialization();
		homepage = new HomePage();
		logInPage = new LogInPage();
		accountSummaryPage = new AccountSummaryPage();
		testUtil=new TestUtil();
		forgotPasswordPage=new ForgotPasswordPage();
	}

	@AfterMethod
	public void cleanUp()
	{
		TestUtil.takeScreenShotAtEndOfTest("LogInPage");
		killDriver();
	
	}
	
	@Test
	public void validateLogInPage()
	{
		logInPage=homepage.clickOnSignInButton();
		logInPage.assertLoginPageTitle();
	}
	
	@Test
	public void validateLogInFunctionality()
	{
		logInPage=homepage.clickOnSignInButton();
		accountSummaryPage=logInPage.logIn();
		accountSummaryPage.assertAccountSummaryPageTitle();
	}
	
	//Adding email id without @ symbol in ForgotPassword Page
	@Test(groups="Regression")
	public void validateForgotPasswordFunctionality_Negative()
	{
		logInPage=homepage.clickOnSignInButton();
		logInPage.assertLoginPageTitle();
		logInPage.forgotPassword();
			
		forgotPasswordPage.forgot_Password();
		forgotPasswordPage.assertForgotPasswordPageTitle();
		
	}

}
