package com.qa.zerobank.testcases;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.zerobank.base.TestBase;
import com.qa.zerobank.pages.FeedbackPage;
import com.qa.zerobank.pages.HomePage;
import com.qa.zerobank.pages.LogInPage;
import com.qa.zerobank.pages.SearchResultPage;
import com.qa.zerobank.util.TestUtil;

public class HomePageTestCases extends TestBase 
{

	HomePage homepage;
	LogInPage logInPage;
	TestUtil testUtil;
	SearchResultPage searchResultPage;
	FeedbackPage feedbackPage;
	
	public HomePageTestCases()
	{
		super();
	}
	
	@BeforeMethod
	public void setUp()
	
	{
		initialization();
		homepage=new HomePage();
		logInPage=new LogInPage();
		testUtil=new TestUtil();
		searchResultPage=new SearchResultPage();
		feedbackPage=new FeedbackPage();
	}
	
	@AfterMethod
	public void cleanUp()
	{
		TestUtil.takeScreenShotAtEndOfTest("HomePage");
		killDriver();
	
	}
	
	@Test
	public void validateHomePage()
	{
		homepage.assertHomePageTitle();
	}
	
	@Test
	public void validateLogo()
	{
		homepage.validateBrandLogo();
	}
	
	@Test
	public void signInButtonTest()
	{
		logInPage=homepage.clickOnSignInButton();
		logInPage.assertLoginPageTitle();
	}
	
	@Test
	public void executeExe()
	{
		testUtil.executeExeFile(System.getProperty("user.dir")+"\\src\\main\\resources\\com\\qa\\zerobank\\seleniumbrowserdriver\\chromedriver.exe");
		
	}
	
	@Test
	public void dbConnectionTest() throws ClassNotFoundException,SQLException
	{
		Connection testcon=testUtil.createDBConnection();
		ResultSet results=testUtil.executeDBQuery(testcon,"select * from student");
		while(results.next())
		{
			String studentname=results.getString("Name");
			System.out.println("My name is:"+studentname);
			
		}
		testUtil.closeConnection(testcon);
		
	}
	
	@Test
	public void search()
	{
		
		searchResultPage.clickOnLink();
	}
	
	//Adding email id with numbers in FeedbackForm
	@Test(groups="Regression")
	public void feedback1()
	{
		homepage.feedback();
		feedbackPage.assertFeedbackPageTitle();
		feedbackPage.give_Feedback1();
	}
	
	//Adding email id without @ symbol in FeedbackForm
	@Test(groups="Regression")
	public void feedback2()
	{
		homepage.feedback();
		feedbackPage.assertFeedbackPageTitle();
		feedbackPage.give_Feedback2();
	}
	
}
