package com.qa.zerobank.testcases;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.zerobank.base.TestBase;
import com.qa.zerobank.pages.AccountSummaryPage;
import com.qa.zerobank.pages.HomePage;
import com.qa.zerobank.pages.LogInPage;

import com.qa.zerobank.pages.TransferFundPage;
import com.qa.zerobank.util.TestUtil;

public class TransferFundTestCase extends TestBase {
	HomePage homepage;
	LogInPage logInPage;
	TransferFundPage transferFundPage;
	AccountSummaryPage accountSummaryPage;
	TestUtil testUtil;

	public TransferFundTestCase() {
		super();
	}

	@BeforeMethod
	public void beforeMethod() {
		initialization();
		homepage = new HomePage();
		logInPage = new LogInPage();
		accountSummaryPage = new AccountSummaryPage();
		testUtil = new TestUtil();
		transferFundPage = new TransferFundPage();
		logInPage = homepage.clickOnSignInButton();
		logInPage.logIn();
	}

	@AfterMethod
	public void cleanUp() {
		TestUtil.takeScreenShotAtEndOfTest("PayBills");
		killDriver();

	}

	@Test(priority = 1)
	public void validateTransferFundPage() {
		accountSummaryPage.assertAccountSummaryPageTitle();
		transferFundPage.transferFund();
		transferFundPage.assertTransferFundPageTitle();
	}

	@Test(priority = 2)
	public void validateTransferFundFunctionality() {
		transferFundPage.transferFund();
		transferFundPage.make_Payment();
	}
	
	
	@Test(priority = 3,groups="Regression")
	public void validateTransferFundFunctionality_negativeAmount() {
		transferFundPage.transferFund();
		transferFundPage.make_Payment_NegativeAmount();
	}
}
