package com.qa.zerobank.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.qa.zerobank.base.TestBase;

public class PayBills extends TestBase {

	@FindBy(id = "sp_payee")
	WebElement payee;

	@FindBy(id = "sp_account")
	WebElement account;

	@FindBy(id = "sp_amount")
	WebElement amount;

	@FindBy(name = "date")
	WebElement date;

	@FindBy(id = "sp_description")
	WebElement description;

	@FindBy(id = "pay_saved_payees")
	WebElement pay_saved_payees;

	@FindBy(xpath = "//a[contains(text(),'Pay Bills')]")
	WebElement click_Pay_Bills;

	@FindBy(xpath = "//a[contains(text(),'Pay Saved Payee')]")
	WebElement click_pay_saved_payees;

	@FindBy(xpath = "//a[contains(text(),'Add New Payee')]")
	WebElement click_Add_New_Payee;
	

	public PayBills() {
		PageFactory.initElements(driver, this);
	}

	public void assertPayBillPageTitle() {
		assertEquals(driver.getTitle(), "Zero - Pay Bills", "Test Failed");
	}

	public void paySavedPayee() {
		click_Pay_Bills.click();
		click_pay_saved_payees.click();
	}

	public PayBills make_Payment() {

		Select spayee = new Select(payee);
		spayee.selectByValue("apple");

		Select saccount = new Select(account);
		saccount.selectByVisibleText("Loan");

		amount.sendKeys("50");

		date.sendKeys("2022-01-03");

		description.sendKeys("Electricity Bills");

		pay_saved_payees.click();
		return new PayBills();
	}

	public PayBills make_Payment_InvalidDate() {

		Select spayee = new Select(payee);
		spayee.selectByValue("apple");

		Select saccount = new Select(account);
		saccount.selectByVisibleText("Loan");

		amount.sendKeys("50");

		date.sendKeys("20203");

		description.sendKeys("Electricity Bills");

		pay_saved_payees.click();
		return new PayBills();
	}
	
	public AddNewPayee Add_New_Payee() {
		click_Pay_Bills.click();
		click_Add_New_Payee.click();
		return new AddNewPayee();
	}
}
