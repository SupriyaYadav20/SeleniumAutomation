package com.qa.zerobank.pages;

import static org.testng.Assert.assertEquals;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.zerobank.base.TestBase;

public class LogInPage extends TestBase {

	@FindBy(id = "user_login")
	WebElement lusername;

	@FindBy(id = "user_password")
	WebElement lpassword;

	@FindBy(className = "icon-question-sign")
	WebElement questionMark;

	@FindBy(id = "user_remember_me")
	WebElement signincheckbox;

	@FindBy(id = "details-button")
	WebElement detailsbutton;

	@FindBy(linkText = "Proceed to zero.webappsecurity.com (unsafe)")
	WebElement proceedtolink;

	@FindBy(linkText = "Forgot your password ?")
	WebElement forgotpassword;

	@FindBy(name = "submit")
	WebElement submit;
			
	public LogInPage() {
		PageFactory.initElements(driver, this);
	}

	public void assertLoginPageTitle() {
		assertEquals(driver.getTitle(), "Zero - Log in", "Test Failed");
	}

	public AccountSummaryPage logIn() {
		lusername.sendKeys(prop.getProperty("uuserid"));
		lpassword.sendKeys(prop.getProperty("password"));
		submit.click();
		
		detailsbutton.click();
		proceedtolink.click();
		return new AccountSummaryPage();
	}
	
	public ForgotPasswordPage forgotPassword()
	{
		
		forgotpassword.click();
		return new ForgotPasswordPage();
	}
}
