package com.qa.zerobank.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.zerobank.base.TestBase;

public class AddNewPayee  extends TestBase{
	
	
	@FindBy(name = "np_new_payee_name")
	WebElement new_payee_name;
	
	@FindBy(name = "np_new_payee_address")
	WebElement new_payee_address;
	
	
	@FindBy(name = "np_new_payee_account")
	WebElement new_payee_account;
	
	@FindBy(name = "np_new_payee_details")
	WebElement new_payee_details;
	
	@FindBy(name = "add_new_payee")
	WebElement add_new_payee;
	
	public AddNewPayee() {
		PageFactory.initElements(driver, this);
	}

	public void assertPayBillPageTitle() {
		assertEquals(driver.getTitle(), "Zero - Pay Bills", "Test Failed");
	}
	
	public void Add_New_Payee() {
		
		
		new_payee_name.sendKeys("12345");
		new_payee_address.sendKeys("Pune");
		new_payee_account.sendKeys("Saving");
		new_payee_details.sendKeys("Supriya Yadav");
		add_new_payee.click();
	}
	
	

}
