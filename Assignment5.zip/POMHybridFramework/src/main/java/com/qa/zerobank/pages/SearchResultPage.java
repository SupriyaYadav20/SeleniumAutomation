package com.qa.zerobank.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.zerobank.base.TestBase;

public class SearchResultPage extends TestBase
{

	
	@FindBy(partialLinkText = "Zero ")
	WebElement resultFound;
	
	@FindBy(partialLinkText = "No results were found for the query:")
	WebElement resultNotFound;
	
	
	public SearchResultPage() {
		PageFactory.initElements(driver, this);
	}

	public void assertSearchResultPage() {
		assertEquals(driver.getTitle(), "Zero - Search Tips", "Test Failed");
	}
	
	public LogInPage clickOnLink()
	{
		resultFound.click();
		return new LogInPage();
		
	}
}
