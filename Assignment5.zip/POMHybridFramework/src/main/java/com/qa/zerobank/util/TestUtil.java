package com.qa.zerobank.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.commons.io.FileUtils;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Sheet;
//import org.apache.poi.sl.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import com.qa.zerobank.base.TestBase;

public class TestUtil extends TestBase {

	static JavascriptExecutor js;
	Connection con;

	public static String TESTDATA_SHEET_PATH = System.getProperty("user.dir")
			+ "\\src\\test\\resources\\com\\qa\\zerobank\\testdata\\" + prop.getProperty("testdata");
	static Workbook book;
	static Sheet sheet;

	public static Object[][] getTestData(String sheetname) {
		FileInputStream file = null;
		try {
			file = new FileInputStream(TESTDATA_SHEET_PATH);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			book = WorkbookFactory.create(file);
		} catch (EncryptedDocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		sheet = book.getSheet(sheetname);

		int rowCount = sheet.getLastRowNum();
		int columnCount = sheet.getRow(0).getLastCellNum();

		Object[][] data = new Object[rowCount][columnCount];

		for (int i = 0; i < sheet.getLastRowNum(); i++) {
			for (int j = 0; j < sheet.getRow(0).getLastCellNum(); j++) {
				data[i][j] = sheet.getRow(i + 1).getCell(j).toString();
				// System.out.println(data[i][j]);
			}
		}
		return data;
	}

	public static void takeScreenShotAtEndOfTest(String pagename) {
		File srcFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		String homeDir = System.getProperty("user.dir");
		try {
			FileUtils.copyFile(srcFile,
					new File(homeDir + "/screenshot/" + pagename + System.currentTimeMillis() + ".png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void executeExeFile(String fileName) {
		try {
			Runtime.getRuntime().exec(fileName);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void executeJavaScript(String jsQuery) {
		js = (JavascriptExecutor) driver;
		js.executeScript(jsQuery);

	}

	// Open DB Connection
	public Connection createDBConnection() throws ClassNotFoundException, SQLException {
		// load driver jar class
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("MYSQL connection is done");
		
		// create connection
		con = DriverManager.getConnection("jdbc:mysql://" + prop.getProperty("dbhost") + ":" + prop.getProperty("port")
				+ "/" + prop.getProperty("dbname"),prop.getProperty("dbuser") , prop.getProperty("dbpassword"));

		System.out.println("Connected to MYSQL Database");
		return con;
	}

	// Process the Query
	public ResultSet executeDBQuery(Connection con, String Query) throws SQLException {
		// create statement
		Statement smt = con.createStatement();

		// Execute Query
		ResultSet rs = smt.executeQuery(Query);
		System.out.println(rs);

		return rs;
	}

	// close connection
	public void closeConnection(Connection con) throws SQLException {
		con.close();
	}
}
