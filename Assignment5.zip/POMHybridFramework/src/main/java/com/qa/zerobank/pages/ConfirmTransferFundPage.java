package com.qa.zerobank.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.zerobank.base.TestBase;

public class ConfirmTransferFundPage extends TestBase
{

	
	@FindBy(xpath = "//h2[contains(text(),'Transfer Money & Make Payments - Verify')]")
	WebElement Verify;
	
	@FindBy(id = "btn_cancel")
	WebElement btn_cancel;
	
	@FindBy(id = "btn_submit")
	WebElement btn_submit;
	
	@FindBy(xpath = "//div[contains(text(),'You successfully submitted your transaction.')]")
	WebElement message;
	
	public ConfirmTransferFundPage() {
		PageFactory.initElements(driver, this);
	}

	public void assertConfirmTransferFundPage() {
		assertEquals(driver.getTitle(), "Zero - Search Tips", "Test Failed");
	}
	
	public void clickOnLink()
	{
		btn_submit.click();
		assertEquals(message.getText(),"You successfully submitted your transaction.","Test Failed");
	}
}
