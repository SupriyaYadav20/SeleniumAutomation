package com.qa.zerobank.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.zerobank.base.TestBase;

public class ForgotPasswordPage extends TestBase {
	@FindBy(id = "user_email")
	WebElement email;
	
	@FindBy(name = "submit")
	WebElement submit;
	

	public ForgotPasswordPage() {
		PageFactory.initElements(driver, this);
	}

	public void assertForgotPasswordPageTitle() {
		assertEquals(driver.getTitle(), "Zero - Forgotten Password", "Test Failed");
	}
	
	public void forgot_Password() {
		email.sendKeys("Supriya123");
		submit.click();
	}
	
}
