package com.qa.zerobank.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.zerobank.base.TestBase;

public class FeedbackPage extends TestBase {

	@FindBy(id = "name")
	WebElement name;

	@FindBy(id = "email")
	WebElement email;

	@FindBy(id = "subject")
	WebElement subject;

	@FindBy(id = "comment")
	WebElement comment;

	@FindBy(name = "submit")
	WebElement submit;

	@FindBy(name = "clear")
	WebElement clear;

	public FeedbackPage() {
		PageFactory.initElements(driver, this);
	}

	public void assertFeedbackPageTitle() {
		assertEquals(driver.getTitle(), "Zero - Contact Us", "Test Failed");
	}

	// **********Adding email id with numbers in
	// FeedbackForm***********************************************
	
	public void give_Feedback1() {
		name.sendKeys("Supriya");
		email.sendKeys("12345");
		subject.sendKeys("No registration page");
		comment.sendKeys("There is no registration page for login");
		submit.click();
	}

	// **********Verify the email id field With Missing @ symbol (
	public void give_Feedback2() {
		name.sendKeys("Supriya");
		email.sendKeys("supriya.com");
		subject.sendKeys("No registration page");
		comment.sendKeys("There is no registration page for login");
		submit.click();
	}
}
