package com.qa.zerobank.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.qa.zerobank.base.TestBase;

public class TransferFundPage extends TestBase{
	
	@FindBy(xpath = "//a[contains(text(),'Transfer Funds')]")
	WebElement transfer_Funds;
	
	@FindBy(id = "tf_fromAccountId")
	WebElement fromAccountId;
	
	@FindBy(id = "tf_toAccountId")
	WebElement toAccountId;
	
	@FindBy(id = "tf_amount")
	WebElement amount;
	
	@FindBy(id = "tf_description")
	WebElement description;
	
	@FindBy(id = "btn_submit")
	WebElement submit;
	
	public TransferFundPage() {
		PageFactory.initElements(driver, this);
	}

	public void assertTransferFundPageTitle() {
		assertEquals(driver.getTitle(), "Zero - Transfer Funds", "Test Failed");
	}
	public void transferFund()
	{
		transfer_Funds.click();
		//click_pay_saved_payees.click();
	}
	
	public ConfirmTransferFundPage make_Payment() {
		
		
		Select spayee=new Select(fromAccountId);
		spayee.selectByValue("2");
		
		Select saccount=new Select(toAccountId);
		saccount.selectByValue("2");
		
		amount.sendKeys("50");
		
		description.sendKeys("Electricity Bills");
		
		submit.click();
		return new ConfirmTransferFundPage ();
	}
	
	
public ConfirmTransferFundPage make_Payment_NegativeAmount() {
		
		
		Select spayee=new Select(fromAccountId);
		spayee.selectByValue("2");
		
		Select saccount=new Select(toAccountId);
		saccount.selectByValue("2");
		
		amount.sendKeys("-50");
		
		description.sendKeys("Electricity Bills");
		
		submit.click();
		return new ConfirmTransferFundPage ();
	}
	
}
