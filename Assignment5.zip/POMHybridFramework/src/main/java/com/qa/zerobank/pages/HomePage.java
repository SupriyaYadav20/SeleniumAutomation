package com.qa.zerobank.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.zerobank.base.TestBase;

public class HomePage extends TestBase {

	// Object Repository
	@FindBy(id = "signin_button")
	WebElement signin;

	@FindBy(name = "searchTerm")
	WebElement search;

	@FindBy(linkText = "Zero Bank")
	WebElement zeroBank;

	
	@FindBy(xpath = "//strong[contains(text(),'Feedback')]")
	WebElement feedback;

	@FindBy(linkText = "Online Banking")
	WebElement onlinebanking;

	@FindBy(id = "online-banking")
	WebElement online_banking;

	@FindBy(xpath = "//body/div[2]/div[1]/div[1]/div[2]/div[1]/a[1]")
	WebElement privacy;

	@FindBy(className = "brand")
	WebElement brandLogo;	

	public HomePage() {
		PageFactory.initElements(driver, this);
	}

	public void assertHomePageTitle() {
		assertEquals(driver.getTitle(), "Zero - Personal Banking - Loans - Credit Cards", "Test Failed");
	}

	public boolean validateBrandLogo() {
		return brandLogo.isDisplayed();

	}

	public LogInPage clickOnSignInButton() {
		signin.click();
		return new LogInPage();
	}

	public SearchResultPage searchBox(String searchData) {

		search.click();
		search.sendKeys("searchData");
		search.sendKeys(Keys.ENTER);

		return new SearchResultPage();
	}
	
	public FeedbackPage feedback() {
		feedback.click();
		return new FeedbackPage();
	}
}
